var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0 Comments","multiple":"{num} Comments","one":"1 Comment"}},"counts":[{"id":"http:\/\/www.sitepoint.com\/testing-across-node-js-versions-using-docker\/","comments":1},{"id":"http:\/\/www.sitepoint.com\/understanding-angulars-apply-digest\/","comments":15}]});
}